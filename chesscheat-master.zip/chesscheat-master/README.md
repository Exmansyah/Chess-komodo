<h1>Chess Cheat</h1>
<p>Cheat catur ini menggunakan mesin Stockfish dan kekuatan komputer Anda untuk menunjukkan langkah terbaik yang harus diambil dalam setiap permainan di chess.com. Ini menjamin Anda menang setidaknya dalam 90% permainan yang Anda mainkan dan dapat sangat membantu Anda meningkatkan keterampilan catur Anda.

<i>Catatan: Proyek ini dikembangkan untuk tujuan pembelajaran. Saya tidak mendukung atau mendorong kecurangan dalam permainan, dan proyek ini seharusnya membantu Anda menjadi lebih baik dalam bermain catur. Permainan yang tidak fair dapat menyebabkan akun chess.com Anda ditangguhkan jika Anda tidak menggunakannya dengan bijak.
 </i>
<br>


https://user-images.githubusercontent.com/71329328/221189107-244544b0-8070-4ee3-973f-c4c9bfa15067.mp4


<h1>Cara install(Khusus Mobile):</h1>
•Pertama, download browser yang mendukung extension, contohnya Quetta.</br></
•Kedua, Install file extensionnya yang berada dibawah.</br></br>
•Ketiga, Buka browser lalu pasang manual file extension tersebut.</br></br>
•Keempat, Selamat Menikmati.</br></br>
<code>
git clone https://github.com/Eugenenoble2005/chesscheat.git
</code>

If you do not have git installed, you may download this repo as a zip by following this link:
<a href = "https://github.com/Eugenenoble2005/chesscheat/archive/refs/heads/master.zip">Zip Download</a>
